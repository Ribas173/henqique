const theme_guiche = {
  bg_primary: '#000000',
  bg_secondary: '#222222',
  hover_primary: '#11D135',
  hover_secondary: '#1e1e1e',
  text: '#ffffff',
  white: '#ffffff',
  black: '#000000',
}

window.theme_color = {
  bg_primary: '#000000',
  bg_secondary: '#222222',
  hover_primary: '#11D135',
  hover_secondary: '#1e1e1e',
  text: '#ffffff',
  white: '#ffffff',
  black: '#000000',
}